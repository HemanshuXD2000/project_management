import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SidenavComponent } from './layouts/sidenav/sidenav.component';
import { CompletedProjectComponent } from './components/completed-projects/completed-projects.component';
import { CardLayoutComponent } from './layouts/card-layout/card-layout.component';
import { WorkForceComponent } from './components/work-force/work-force.component';
import { TaskComponentComponent } from './components/task-component/task-component.component';
import { SubtaskComponentComponent } from './components/subtask-component/subtask-component.component';
import { OngoingProjectComponent } from './components/ongoing-project/ongoing-project.component';
import { ProjectDetailsComponent } from './components/project-details/project-details.component';
import { CreateProjectComponent } from './components/create-project/create-project.component';

const routes: Routes = [
  {
    path: '', component: SidenavComponent,
    children: [{
      path: 'completed',
      component: CompletedProjectComponent,
    },
    {
      path: '',
      component: CardLayoutComponent,
  },
  {
      path: 'project',
      component: CardLayoutComponent,
  },
  {
      path: 'workforce',
      component: WorkForceComponent,

},
{
  path: 'tasks',
  component: TaskComponentComponent,
},
{
  path: 'subtasks',
  component: SubtaskComponentComponent,
},
{
  path: 'ongoing',
  component: OngoingProjectComponent,
},
{
  path: 'details',
  component: ProjectDetailsComponent,
},
{
  path: 'createproject',
  component: CreateProjectComponent,
}]
},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
