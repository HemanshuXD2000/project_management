import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { DialogData } from 'src/app/models/dialog-data';

@Component({
  selector: 'app-completed-dialog',
  templateUrl: './completed-dialog.component.html',
  styleUrls: ['./completed-dialog.component.css']
})
export class CompletedDialogComponent implements OnInit {
  ngOnInit() {
  }

  enval: boolean = true;

  constructor(
    public dialogRef: MatDialogRef<CompletedDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData) {

  }

  onKey(event: any) {
    console.log(this.data.enterProject);
    let project_name = this.data.projectName;
    if(this.data.enterProject.toUpperCase() === project_name.toUpperCase()){

      this.enval = false;
    }
    else{
      this.enval = true;
    }
  }

  onNoClick(): void {
    this.dialogRef.close();
  }
}
