import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { Employee } from 'src/app/models/employee';
import { ProjectMember } from 'src/app/models/project-member';
import { EmployeeServiceService } from 'src/app/services/employee-service.service';

@Component({
  selector: 'app-work-force',
  templateUrl: './work-force.component.html',
  styleUrls: ['./work-force.component.css']
})
export class WorkForceComponent implements OnInit {

  recievedvalue!:string;
  errorMessage: any;
  empdata!:Employee[];

  dataSource: any;
  displayedColumns: string[] = ['firstName', 'email'];
  //variable to hold the deatils of employee that is been searched for
  employeeData: any;
  detailsOfEmployee: ProjectMember[]| undefined;



  @ViewChild(MatPaginator, {static: true}) paginator!: MatPaginator;
  constructor(private employeeService:EmployeeServiceService) {

   }

  ngOnInit() {

    this.employeeService.getAllEmployee().subscribe(result =>{
      this.empdata=result;
      this.dataSource = new MatTableDataSource<Employee>(this.empdata);
      this.dataSource.paginator = this.paginator;
    });
  }

  getEmployDetails(emp:string) //function to approach service to retrieve data
  {
    this.employeeService.getEmployeeData(emp).subscribe(data => {
      this.empdata = data;
      console.log(this.empdata);
      this.dataSource = new MatTableDataSource<Employee>(this.empdata);
      this.dataSource.paginator = this.paginator;
    });
  }

  logData(val:any) //get id of the employee to searched
  {

    this.employeeData = val.getAttribute('data-emp-id');
    console.log(this.employeeData);
    this.getDetails(this.employeeData); // call the function that invokes the employee service to get theemployee information

  }


  //function that invoke the service to get data
  getDetails(val: any) {
    this.employeeService.getEmployeeDetails(val).subscribe(
      info => {
        this.detailsOfEmployee = info;
        this.errorMessage = ''; // Reset the error message

        if (this.detailsOfEmployee.length <= 0) {
          this.errorMessage = 'Employee is not working on any project!';
        }
      },
      error => {
        if (error.status === 404) {
          this.errorMessage = 'Employee is not working on any project!';
        } else {
          // Handle other error cases here
          this.errorMessage = 'An error occurred while fetching employee details.';
        }
      }
    );
  }

  searchEmp(searchData:any)
  {
    if(searchData=="")
    {
      this.employeeService.getAllEmployee().subscribe(result =>{
        this.empdata=result;
        console.log(this.empdata);
        this.dataSource = new MatTableDataSource<Employee>(this.empdata);
      this.dataSource.paginator = this.paginator;
      });
    }
    else{
      this.getEmployDetails(searchData);
    }
  }
}
