import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { Employee } from 'src/app/models/employee';
import { Project } from 'src/app/models/project';
import { ProjectMapper } from 'src/app/models/project-mapper';
import { ProjectMongo } from 'src/app/models/project-mongo';
import { EmployeeServiceService } from 'src/app/services/employee-service.service';
import { ProjectServiceService } from 'src/app/services/project-service.service';

@Component({
  selector: 'app-create-project',
  templateUrl: './create-project.component.html',
  styleUrls: ['./create-project.component.css']
})
export class CreateProjectComponent implements OnInit {

  @ViewChild('projectCreateForm', { static: true }) form: any;
  project!: Project; //For mysql
  projectDescStake!: ProjectMongo;   //For mongo
  projectMapper: ProjectMapper;
  manager: Employee |undefined;
  employees = new Array<Employee>();
  errormsg: boolean = false;


  constructor(
    private router: Router, private projectService: ProjectServiceService,
    private employeeService: EmployeeServiceService
  ) {

      this.projectMapper = new ProjectMapper();

  }


  ngOnInit() {
    this.findAvailableManagers();
  }


  findAvailableManagers() {
    this.employeeService.findAll().subscribe(
      response => {
        this.employees = response.map(item => {
          const employee = new Employee();
          employee.employeeId = item.employeeId;
          employee.firstName = item.firstName;
          employee.lastName = item.lastName;
          employee.middleName = item.middleName;
          employee.username = item.username;
          employee.password = item.password;
          employee.userType = item.userType;
          employee.availability = item.availability;
          employee.eulAgreement = item.eulAgreement;
          console.log(employee);
          return employee;
        });
        if(this.employees.length <= 0){
          this.errormsg = true;
        }
        else{
          this.errormsg = false;
        }
      });
  }



  onSubmit() {
    let poject1: Project;

    //Get the selected manager object from the list
    this.manager = this.employees.find(i => i.username === this.projectMapper.managerEmail);

    //For mysql project table
    this.project = new Project();
    this.project.projectId = 0;
    this.project.isCompleted = false;
    this.project.name = this.projectMapper.name;
    this.project.startDate = this.projectMapper.startDate;
    this.project.endDate = this.projectMapper.endDate;
    this.project.managerId = this.manager;
    console.log(this.manager);
    this.project.budget = this.projectMapper.budget;
    this.project.githubLink = this.projectMapper.githubLink;

    //For mongo database
    this.projectDescStake = new ProjectMongo();
    if(this.projectMapper.projectDesc === undefined){
      this.projectDescStake.projectDesc = '';
    }
    else{
      this.projectDescStake.projectDesc = this.projectMapper.projectDesc;
    }
    this.projectDescStake.stakeholders = this.projectMapper.stakeholders;
    console.log(this.project);
    //Data saving operation
    this.projectService.save(this.project).subscribe(result => {

      poject1 = result;

      this.projectDescStake.projectId = poject1.projectId;
      this.projectService.saveProjectDesc(this.projectDescStake).subscribe(result2 => { });
      this.findAvailableManagers();
    });

    alert('SUCCESS!! :-)\n\n');

    this.form.reset();
  }
}
