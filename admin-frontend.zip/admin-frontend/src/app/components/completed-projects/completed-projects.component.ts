import { ProjectServiceService } from 'src/app/services/project-service.service';
import { Component, OnInit,ViewChild} from '@angular/core';
import {MatPaginator} from '@angular/material/paginator';
import {MatTableDataSource, MatTableDataSourcePaginator} from '@angular/material/table';
import { Project } from 'src/app/models/project';






@Component({
  selector: 'app-completed-projects',
  templateUrl: './completed-projects.component.html',
  styleUrls: ['./completed-projects.component.css']
})
export class CompletedProjectComponent implements OnInit {
  projects : Project[]=[];
  projectdata!: string;
  errormessage: string | undefined;
  dSource!: MatTableDataSource<Project, MatTableDataSourcePaginator>;
  dColumns: string[] = ['name', 'startDate','endDate','action'];
  @ViewChild(MatPaginator, {static: true}) paginator!: MatPaginator;
  constructor(private projectService:ProjectServiceService) { }

  ngOnInit() {
    this.projectService.findCompletedAll().subscribe((response) => {
      if (response.status === 302) {
        // Handle redirection here if needed
        console.log("hello");
        const redirectedUrl = response.headers.get('Location');
        console.log('Redirected to:', redirectedUrl);
      } else if (response.body !== null) {
        // Process the project data here
        this.projects = response.body;

        this.dSource = new MatTableDataSource<Project>(this.projects);
        this.dSource.paginator = this.paginator;
        console.log(this.projects);
      } else {
        // Handle the case where response.body is null
        console.log('Response body is null.');
      }
    });
  }

  gotonext(proj: any)
  {
    this.projectdata = proj.getAttribute('data-project-id');
    sessionStorage.setItem('pid', this.projectdata);
    console.log(proj);
  }

  searchProj(yearData: any) {
    if (yearData == "") {
      this.projectService.findCompletedAll().subscribe(response => {
        const data = response.body; // Extract the body of the HttpResponse
        this.projects = data || []; // Use nullish coalescing

        this.dSource = new MatTableDataSource<Project>(this.projects);
        this.dSource.paginator = this.paginator;
      });
    } else {
      this.getProjectByYear(yearData);
    }
  }

  getProjectByYear(yearData: any)
  {
    this.projectService.getCompletedProjectByYear(yearData).subscribe(yearValue =>{
      this.projects=yearValue;
      if(this.projects.length<=0)
      {
        this.errormessage="Sorry! No Projects created in the year "+yearData+"! ";
      }
      else{
        this.errormessage=""
      }
      this.dSource = new MatTableDataSource<Project>(this.projects);
        this.dSource.paginator = this.paginator;
    });
  }


}
