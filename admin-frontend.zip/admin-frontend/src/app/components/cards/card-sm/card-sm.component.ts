import { Component, Input } from '@angular/core';
import { Employee } from 'src/app/models/employee';
import { Project } from 'src/app/models/project';
import { ProjectServiceService } from 'src/app/services/project-service.service';
import { EmployeeServiceService } from 'src/app/services/employee-service.service';

@Component({
  selector: 'app-card-sm',
  templateUrl: './card-sm.component.html',
  styleUrls: ['./card-sm.component.css']
})
export class CardSmComponent {
  allProjects: Project[]| undefined;
  compProject!: Project[];
  ongProject: Project[]| undefined;
  allEmp: Employee[]| undefined;

  allPorjectcount: number | undefined;
  Completedcount: number | undefined;
  Ongoingcount: number | undefined;
  EmployeeCount:number | undefined;
  data: string | number | undefined;
  iconData: string | undefined;
  @Input()
  cardData: string | undefined;
  constructor(private projectService:ProjectServiceService,private employeeService: EmployeeServiceService) { }

  ngOnInit() {
    this.projectService.getAllProjectDetails().subscribe(data1 => {
      this.allProjects = data1;
      console.log(this.allProjects);
      this.allPorjectcount = this.allProjects.length;

      this.projectService.findCompletedAll().subscribe(response2 => {
        if (response2.status === 302) {
          // Handle redirection here if needed
          const redirectedUrl = response2.headers.get('Location');
          console.log('Redirected to:', redirectedUrl);
        } else {
          // Process the project data here
          this.compProject = response2.body || [];
          this.Completedcount = this.compProject.length;

          this.projectService.findOngoing().subscribe(data3 => {
            this.ongProject = data3;
            this.Ongoingcount = this.ongProject.length;

            this.employeeService.getAllEmployee().subscribe(data4 => {
              this.allEmp = data4;
              this.EmployeeCount = this.allEmp.length;
              this.check_card_data();
            });
          });
        }
      });
    });
  }


  check_card_data() {
    switch (this.cardData) {
      case 'Total':

        this.data = this.allPorjectcount;
        this.iconData = 'assessment';
        break;
      case 'Completed':

        this.data = this.Completedcount;
        this.iconData = 'assessment';
        break;
      case 'Ongoing':
        this.data = this.Ongoingcount;
        this.iconData = 'assessment';
        break;
      case 'Employees':
          this.data = this.EmployeeCount;
          this.iconData = 'assessment';
          break;
      default:
        this.data = 'data missing';
    }
  }

}
