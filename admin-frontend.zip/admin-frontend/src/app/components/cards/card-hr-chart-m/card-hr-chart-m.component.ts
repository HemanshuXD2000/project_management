import { Component } from '@angular/core';
import { Chart, LinearScale, DoughnutController,BarController,ArcElement, CategoryScale, BarElement} from 'chart.js';
import { Project } from 'src/app/models/project';
import { Task } from 'src/app/models/task';
import { ProjectServiceService } from 'src/app/services/project-service.service';
import { TaskServiceService } from 'src/app/services/task-service.service';

Chart.register(LinearScale, DoughnutController, BarController, ArcElement, CategoryScale, BarElement );

@Component({
  selector: 'app-card-hr-chart-m',
  templateUrl: './card-hr-chart-m.component.html',
  styleUrls: ['./card-hr-chart-m.component.css']
})
export class CardHrChartMComponent {
  barchart: any;
  tasks: Task[]=[];
  labels:any = [];
  progress:any = [];
  taskCount!: number;
  taskHeader = 'Tasks';
  taskSubtitle = 'Task Progress';
  projectId!: number;
  project!: Project;
  constructor(private projectService: ProjectServiceService, private taskService: TaskServiceService) { }

  ngOnInit() {
     this.projectId = Number(sessionStorage.getItem('pid'));
    this.taskService.findTask(this.projectId).subscribe(response => {
      this.tasks = response;
      this.getTaskDetails();
      this.populateChart();
    });
  }

  getTaskDetails() {
    for (const task of this.tasks) {
      this.labels.push(task.taskTitle);
      this.progress.push(task.progress);
    }
  }

  populateChart() {
    console.log('Labels:', this.labels);
    console.log('Progress:', this.progress);

    this.barchart = new Chart('barchart_canvas', {
      type: 'bar',
      data: {
        labels: this.labels,
        datasets: [{
          label: 'Percentage of Task Completion',
          data: this.progress,
          backgroundColor: [
            'rgba(255,99,132,0.2)',
            'rgba(0,255,0,0.2)',
            'rgba(0,0,255,0.3)'
          ]
        }]
      },
      options: {
        scales: {
          y: {
            beginAtZero: true,
            max: 100 // Set the maximum value of the x-axis to 100 (progress percentage)
          }
        }
      }
    });
  }

  refresh() {
    this.labels = [];
    this.progress = [];
    this.ngOnInit();
  }

}
