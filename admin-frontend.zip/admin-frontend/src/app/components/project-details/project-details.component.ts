import { Component, OnInit } from '@angular/core';
import { Project } from 'src/app/models/project';
import { ProjectMongo } from 'src/app/models/project-mongo';
import { ProjectServiceService } from 'src/app/services/project-service.service';

@Component({
  selector: 'app-project-details',
  templateUrl: './project-details.component.html',
  styleUrls: ['./project-details.component.css']
})
export class ProjectDetailsComponent implements OnInit {

  projects!:Project;
  mongodata!:ProjectMongo[];

  constructor(
     private projectService:ProjectServiceService
  ) { }

  ngOnInit() {


    this.getProject(sessionStorage.getItem("pid"));

}
getProject( id:any ) {
  this.projectService.getProjectById(id).subscribe(
    proj => {
    this.projects = proj;
    console.log(this.projects, proj);
    console.log('Nid: ' +this.projects.budget);
    this.projectService?.findMongodata(id).subscribe(
      resultvalue => {
        this.mongodata= resultvalue;
        console.log(this.mongodata);
      }
    )
    });
  }
}
