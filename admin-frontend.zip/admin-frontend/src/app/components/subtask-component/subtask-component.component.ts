import { Component, OnInit } from '@angular/core';
import { Subtask } from 'src/app/models/subtask';
import { SubtaskServiceService } from 'src/app/services/subtask-service.service';

@Component({
  selector: 'app-subtask-component',
  templateUrl: './subtask-component.component.html',
  styleUrls: ['./subtask-component.component.css']
})
export class SubtaskComponentComponent implements OnInit {

  public subtask!:Subtask[];
  errorMessage!:string;
  constructor(private subtaskService:SubtaskServiceService) { }

  ngOnInit() {

    this.getSubTasks(sessionStorage.getItem("pid"),sessionStorage.getItem("tid"))
  }

  getSubTasks( pid:any,tid:any) {
    this.subtaskService.getSubtask(pid,tid).subscribe(
    task => {
    this.subtask = task;
    if(this.subtask.length<=0)
    {
      this.errorMessage ="No Sub tasks added yet!"
    }
    console.log(this.subtask.length);
    },
    err => {
    console.log(err);
    }
    );
    }
    determineProgressBarColor(progress: any): string {
      if (progress >= 90) {
        return 'accent'; // Green
      } else if (progress >= 50) {
        return 'primary'; // Blue
      } else if (progress >= 15) {
        return 'warn'; // Yellow
      } else {
        return 'warn'; // Red
      }
    }
}
