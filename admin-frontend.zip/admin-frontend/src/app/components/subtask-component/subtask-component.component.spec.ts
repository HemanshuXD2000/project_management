import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SubtaskComponentComponent } from './subtask-component.component';

describe('SubtaskComponentComponent', () => {
  let component: SubtaskComponentComponent;
  let fixture: ComponentFixture<SubtaskComponentComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SubtaskComponentComponent]
    });
    fixture = TestBed.createComponent(SubtaskComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
