import { Component, OnInit } from '@angular/core';
import { Task } from 'src/app/models/task';
import { TaskServiceService } from 'src/app/services/task-service.service';

@Component({
  selector: 'app-task-component',
  templateUrl: './task-component.component.html',
  styleUrls: ['./task-component.component.css']
})
export class TaskComponentComponent implements OnInit{
  errorMessage!:string;
  tasks!: Task[];
  taskdata: any;

  constructor(private taskService: TaskServiceService) { }

  ngOnInit() {
    this.getTasks(sessionStorage.getItem("pid"));

  }
  getTasks( id:any) {
    this.taskService.getTaskById(id).subscribe(
    task => {
        this.tasks = task;
        if(this.tasks.length<=0)
        {
          this.errorMessage="No tasks added yet!"
        }
    console.log(this.tasks);
    },
    err => {
    console.log(err);
    }
    );
    }

  logId(val:any){
    this.taskdata = val.getAttribute('data-task-id');
    console.log(this.taskdata);
    sessionStorage.setItem('tid',this.taskdata);
  }



}
