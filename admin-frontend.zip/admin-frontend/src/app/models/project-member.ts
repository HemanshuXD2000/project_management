import { Employee } from "./employee";
import { Project } from "./project";

export class ProjectMember {
    projectId: Project| undefined;
    employeeId: Employee| undefined;
    authority: boolean| undefined;
}
