import { Employee } from "./employee";

export class Subtask {
    subTaskId: number | undefined;
    taskId: number | undefined;
    employeeId: Employee | undefined;
    subTaskTitle: string | undefined;
    comment: string | undefined;
    subTaskDescription: string | undefined;
    startDate: Date | undefined;
    dueDate: Date | undefined;
    progressPercentage: number | undefined;
}
