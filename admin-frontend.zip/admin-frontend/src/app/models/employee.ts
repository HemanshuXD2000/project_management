export class Employee {
    employeeId!: number;
    firstName!: string;
    lastName: string| undefined;
    middleName: string| undefined;
    username: string| undefined;
    password: string| undefined;
    userType: string| undefined;
    availability: boolean| undefined;
    eulAgreement: boolean| undefined;

}
