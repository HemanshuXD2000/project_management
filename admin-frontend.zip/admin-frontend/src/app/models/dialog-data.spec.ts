import { DialogData } from './dialog-data';

describe('DialogData', () => {
  it('should create an instance', () => {
    expect(new DialogData()).toBeTruthy();
  });
});
