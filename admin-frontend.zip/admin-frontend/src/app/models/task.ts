import { Project } from './project';

export class Task {
    taskId: number | undefined ;
    projectId: Project | undefined;
    taskTitle!: string;
    description: string | undefined;
    startDate: Date | undefined;
    dueDate: Date | undefined;
    subTaskCount: number | undefined;
    progress!: number;

}
