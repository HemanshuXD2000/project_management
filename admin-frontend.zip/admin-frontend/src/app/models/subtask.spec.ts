import { Subtask } from './subtask';

describe('Subtask', () => {
  it('should create an instance', () => {
    expect(new Subtask()).toBeTruthy();
  });
});
