import { ProjectMongo } from './project-mongo';

describe('ProjectMongo', () => {
  it('should create an instance', () => {
    expect(new ProjectMongo()).toBeTruthy();
  });
});
