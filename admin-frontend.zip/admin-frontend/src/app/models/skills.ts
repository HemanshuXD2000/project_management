export class Skills {
    skillId: number| undefined;
    skillName: string| undefined;
}
