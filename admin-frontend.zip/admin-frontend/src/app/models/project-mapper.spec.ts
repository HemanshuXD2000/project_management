import { ProjectMapper } from './project-mapper';

describe('ProjectMapper', () => {
  it('should create an instance', () => {
    expect(new ProjectMapper()).toBeTruthy();
  });
});
