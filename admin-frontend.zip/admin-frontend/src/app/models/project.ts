import { Employee } from "./employee";

export class Project {
    projectId: number| undefined;
    name: string| undefined;
    startDate  : string| undefined;
    endDate : string| undefined;
    managerId : Employee| undefined;
    budget! : number| undefined;
    isCompleted: boolean| undefined;
    githubLink: string| undefined;
}
