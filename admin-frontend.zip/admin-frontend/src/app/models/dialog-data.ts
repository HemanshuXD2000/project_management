export class DialogData {
    enterProject!: string;
    projectName!: string;
}
