import { Projectmongo } from './projectmongo';

describe('Projectmongo', () => {
  it('should create an instance', () => {
    expect(new Projectmongo()).toBeTruthy();
  });
});
