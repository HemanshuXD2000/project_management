export class ProjectMongo {
    projectId: number | undefined;
    projectDesc : string | undefined;
    stakeholders : string | undefined;
}
