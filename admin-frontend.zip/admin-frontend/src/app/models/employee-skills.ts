import { Employee } from "./employee";
import { Skills } from "./skills";

export class EmployeeSkills {
    employeeId: Employee| undefined;
    skillId: Skills| undefined;
}
