import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CardSmComponent } from './components/cards/card-sm/card-sm.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MaterialModule } from './modules/material/material.module';
import { MatPaginatorModule } from '@angular/material/paginator';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { NgCircleProgressModule } from 'ng-circle-progress';
import { SidenavComponent } from './layouts/sidenav/sidenav.component';
import { CompletedProjectComponent } from './components/completed-projects/completed-projects.component';
import { CardLayoutComponent } from './layouts/card-layout/card-layout.component';
import { CardHrChartMComponent } from './components/cards/card-hr-chart-m/card-hr-chart-m.component';
import { CompletedDialogComponent } from './components/completed-dialog/completed-dialog.component';
import { CardVrChartMComponent } from './cards/card-vr-chart-m/card-vr-chart-m.component';
import { WorkForceComponent } from './components/work-force/work-force.component';
import { TaskComponentComponent } from './components/task-component/task-component.component';
import { SubtaskComponentComponent } from './components/subtask-component/subtask-component.component';
import {MatProgressBarModule} from '@angular/material/progress-bar';
import { OngoingProjectComponent } from './components/ongoing-project/ongoing-project.component';
import { ProjectDetailsComponent } from './components/project-details/project-details.component';
import { CreateProjectComponent } from './components/create-project/create-project.component';

@NgModule({
  declarations: [
    AppComponent,
    CardSmComponent,
    SidenavComponent,
    CompletedProjectComponent,
    CardLayoutComponent,
    CardHrChartMComponent,
    CompletedDialogComponent,
    CardVrChartMComponent,
    WorkForceComponent,
    TaskComponentComponent,
    SubtaskComponentComponent,
    OngoingProjectComponent,
    ProjectDetailsComponent,
    CreateProjectComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MaterialModule,
    MatPaginatorModule,
    ReactiveFormsModule,
    FormsModule,
    //RecaptchaModule,
    //RecaptchaFormsModule,
    HttpClientModule,
    //MatGridListModule,
    //ProgressBarModule,
    //MatBadgeModule,
    MatProgressBarModule,
    BrowserAnimationsModule,
    NgCircleProgressModule.forRoot({
      radius: 100,
      outerStrokeWidth: 16,
      outerStrokeColor: "#78C000",
      animationDuration: 300,
      showInnerStroke: false,
      showSubtitle: false,
      maxPercent: 100,
      unitsFontSize: "50",
      titleFontSize: "50",
      responsive: true
    })
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { };


