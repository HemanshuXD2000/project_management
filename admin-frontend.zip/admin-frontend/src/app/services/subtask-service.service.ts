import { Injectable } from '@angular/core';
import { Subtask } from '../models/subtask';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SubtaskServiceService {

  private subUrl: string;
  private subtaskURL: string;
  private saveSubTaskURL: string;
  private subByTask: string;
  constructor(private http: HttpClient) {
    this.subUrl = 'http://localhost:9999/admin-service/api/v1/subtasks/findAll';
    this.subByTask = "http://localhost:9999/admin-service/api/v1/subtasks";
    this.subtaskURL = 'http://localhost:9999/manager-service/subtask/SubTaskByTaskId';
    this.saveSubTaskURL = 'http://localhost:9999/manager-service/subtask/SubTask';
  }

  public getSubtask(pid: number, tid: number): Observable<Subtask[]> {
    const url = `${this.subByTask}/${pid}/${tid}`;
    console.log(url);
    return this.http.get<Subtask[]>(url);
  }
  public findSubTask(taskId: number): Observable<Subtask[]> {

    return this.http.get<Subtask[]>(this.subtaskURL + '/' + taskId);
  }

  public save(subtask: Subtask) {
    return this.http.post<Subtask>(this.saveSubTaskURL, subtask);
  }
}
