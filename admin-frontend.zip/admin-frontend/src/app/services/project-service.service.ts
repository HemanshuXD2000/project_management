import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Project } from './../models/project';
import {ProjectMongo} from './../models/project-mongo';

@Injectable({
  providedIn: 'root'
})
export class ProjectServiceService {

  private projectUrl: string;
  private projectManagerUrl : string;
  private projectDescServiceUrl : string;

  private projectByIdUrl: string;
  private completeProjectUrl: string;

  constructor(private http: HttpClient) {
    this.projectUrl = 'http://localhost:9999/admin-service/api/v1/projects';


    this.projectManagerUrl = 'http://localhost:7000/project/Project';
    this.projectDescServiceUrl = 'http://localhost:9999/manager-service/projectDesc/saveProjectDesc';
    this.projectByIdUrl = 'http://localhost:9999/manager-service/project/ProjectById';
    this.completeProjectUrl = 'http://localhost:7000/project/CompleteProject';
  }
//get all projects
  public getAllProjectDetails(): Observable<Project[]> {
    var all = "findAll";
    const url = `${this.projectUrl}/${all}`;
    var value= this.http.get<Project[]>(url);
    console.log(value);
    return value;
 }
  public findCompletedAll(): Observable<HttpResponse<Project[]>> {
     var comp="completed";
     console.log(comp);
     const url = `${this. projectUrl}/${comp}`;

     var value= this.http.get<Project[]>(url,{ observe: 'response'});
     console.log(value);
     return value;


  }

  public findOngoing(): Observable<Project[]> {
   var ong="ongoing";
    const url = `${this. projectUrl}/${ong}`;
   return this.http.get<Project[]>(url);

  }


//get project by id from sql
  public getProjectById(id: number): Observable<Project> {
    var str = "findById";
    const url = `${this. projectUrl}/${str}/${id}`;
    console.log(url);
     return this.http.get<Project>(url);
    }

//get project detail by id from mongo
    public findMongodata(id: number): Observable<ProjectMongo[]> {
      var mong="mongodb";
      const url = `${this. projectUrl}/${mong}/${id}`;
      return this.http.get<ProjectMongo[]>(url);
      }

  public getOngoingProjectByYear(yr:number):Observable<Project[]> {
    var pyr = "ongoing";
    const url = `${this.projectUrl}/${pyr}/${yr}`;
    return this.http.get<Project[]>(url);
  }

  public getCompletedProjectByYear(yr:number):Observable<Project[]> {
    var pyr ="completed";
    const url = `${this.projectUrl}/${pyr}/${yr}`;
    return this.http.get<Project[]>(url);
  }

  public saveProjectDesc(projectDescStake: ProjectMongo) {

    return this.http.post<ProjectMongo>(this.projectDescServiceUrl, projectDescStake);
  }


  public findAll(): Observable<Project[]> {
    return this.http.get<Project[]>(this.projectManagerUrl);
  }

  public save(project: Project) {
    return this.http.post<Project>(this.projectManagerUrl, project);
  }

  public findById(id: number): Observable<Project> {
    return this.http.get<Project>(this.projectByIdUrl + '/' + id);
  }

  public setProjectComplete(project: Project) {
    return this.http.put<boolean>(this.completeProjectUrl, project);
  }
}
