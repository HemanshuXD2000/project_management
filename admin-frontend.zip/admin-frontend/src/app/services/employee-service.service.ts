import { EventEmitter, Injectable } from '@angular/core';
import { EmployeeSkills } from '../models/employee-skills';
import { ProjectMember } from '../models/project-member';
import { Observable } from 'rxjs';
import { Employee } from '../models/employee';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class EmployeeServiceService {

  private employeeUrl;
  private memberUrl;
  private managerURL: string;
  employeeURL: string;
  private skilledEmployeeURL: string;
  private skillUrl: string;
  receivedFilter: EventEmitter<string>;


  constructor(private http: HttpClient) {
    this.employeeUrl = 'http://localhost:9999/admin-service/api/v1/employees/findAll';
    this.memberUrl = 'http://localhost:9999/admin-service/api/v1/project_members/getEmp';

    this.managerURL = 'http://localhost:9999/manager-service/employee/getManagersByAvailability';
    this.skilledEmployeeURL = 'http://localhost:9999/manager-service/employeeSkill/getEmployeesBySkills';
    this.skillUrl = 'http://localhost:9999/manager-service/employeeSkill/getEmployeeSkills'


    this.employeeURL = 'http://localhost:9999/manager-service/employee/getMembersByAvailability';

    this.receivedFilter = new EventEmitter<string>();
  }
  //fetch all employee detials
  public getAllEmployee(): Observable<Employee[]> {
    return this.http.get<Employee[]>(this.employeeUrl);
  }
  //get employee details on search string
  public getEmployeeData(searchData: string): Observable<Employee[]> {
    const url = `${this.employeeUrl}/${searchData}`;

    var valu = this.http.get<Employee[]>(url);
    console.log(valu);
    return valu;
  }

  raiseEvent(dataTosearch: string): void {
    this.receivedFilter.emit(dataTosearch);
  }

  public getEmployeeDetails(empid: number): Observable<ProjectMember[]> {

    const url = `${this.memberUrl}/${empid}`;
    return this.http.get<ProjectMember[]>(url);
  }

  public getEmployeeSkills(empid: number): Observable<EmployeeSkills[]> {
    const url = `${this.skillUrl}/${empid}`;
    return this.http.get<EmployeeSkills[]>(url);
  }

  public findAll(): Observable<Employee[]> {
    return this.http.get<Employee[]>(this.managerURL);
  }


  public findSkilledEmployee(skill: String): Observable<Employee[]> {

    return this.http.get<Employee[]>(this.skilledEmployeeURL + '/' + skill);
  }
}
